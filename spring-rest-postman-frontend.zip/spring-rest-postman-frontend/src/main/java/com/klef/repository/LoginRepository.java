//package com.klef.repository;
//
//import org.springframework.data.jpa.repository.JpaRepository;
//
//import com.klef.entity.Login;
//
//
//public interface LoginRepository extends JpaRepository<Login, Integer> {
//
////	public String addLogin(Login ln);
//
//
//
//}
