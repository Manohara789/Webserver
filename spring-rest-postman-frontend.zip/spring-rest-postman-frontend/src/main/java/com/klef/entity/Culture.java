//package com.klef.entity;
//
//import javax.persistence.Entity;
//import javax.persistence.Id;
//import javax.persistence.Table;
//@Entity
//@Table(name = "Culture")
//
//public class Culture {
//	
//		@Id
//		private Long id;
//		private String state;	
//		private String formOfInviting;	
//		
//			
//		public Long getId() {
//			return id;
//		}
//		public void setId(Long id) {
//			this.id = id;
//		}
//		
//		public String getState() {
//			return state;
//		}
//		public void setState(String state) {
//			this.state = state;
//		}
//		public String getFormOfInviting() {
//			return formOfInviting;
//		}
//		public void setFormOfInviting(String formOfInviting) {
//			this.formOfInviting = formOfInviting;
//		}
//		@Override
//		public String toString() {
//			return "Culture [id=" + id + ", state=" + state + ", formOfInviting=" + formOfInviting + "]";
//		}
//		
//	}
//
//
