//package com.klef.entity;
//
//import javax.persistence.Entity;
//import javax.persistence.Id;
//import javax.persistence.Table;
//
//
//@Entity
//@Table(name="login")
//public class Login {
////@Id
////private int l_id;
//
//@Id	
//private String username;
//
//private String password;
//
//
//
//
//
////public int getL_id() {
////	return l_id;
////}
////
////public void setL_id(int l_id) {
////	this.l_id = l_id;
////}
//
//public String getUsername() {
//	return username;
//}
//
//public void setUsername(String username) {
//	this.username = username;
//}
//
//public String getPassword() {
//	return password;
//}
//
//public void setPassword(String password) {
//	this.password = password;
//}
//
//@Override
//public String toString() {
//	return "Login [username=" + username + ", password=" + password + "]";
//}
//
//
//
//
//
//
//
//}
